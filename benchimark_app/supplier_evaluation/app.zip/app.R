library(shiny)
library(shinyjs)
library(bslib)
library(DT)
library(data.table)
library(lubridate)
library(shinyalert)
library(plotly)
library(readr)
library(dplyr)
library(pagedown) # for PDF export

# Read the city data
it_city <- read_csv(file = "data/it.csv")

# Define UI for the app
ui <- page_navbar(
  title = "Suppliers' Benchmark Report",
  theme = bs_theme(version = 5, bootswatch = "minty"),
  
  nav_panel(
    "Dashboard",
    layout_columns(
      fill = FALSE,
      value_box(
        title = "Total Suppliers",
        value = textOutput("total_suppliers"),
        showcase = bsicons::bs_icon("people-fill"),
        theme = "primary"
      ),
      value_box(
        title = "Average Quality Score",
        value = textOutput("avg_quality"),
        showcase = bsicons::bs_icon("star-fill"),
        theme = "success"
      ),
      value_box(
        title = "Top Performer",
        value = textOutput("top_performer"),
        showcase = bsicons::bs_icon("trophy-fill"),
        theme = "warning"
      )
    ),
    
    layout_columns(
      col_widths = c(8, 4),
      card(
        full_screen = TRUE,
        card_header("Supplier Performance Radar Chart"),
        plotlyOutput("radarChart")
      ),
      card(
        card_header("Top Performers Rankings"),
        tableOutput("rankings")
      )
    ),
    
    layout_columns(
      card(
        full_screen = TRUE,
        card_header("Geographical Distribution"),
        plotlyOutput("scattermap")
      )
    ),
    
    card(
      card_header(
        "Supplier Database",
        extra_class = "bg-primary text-light"
      ),
      div(
        class = "p-3",
        fileInput("upload_csv", "Upload Supplier Data (CSV)", accept = c(".csv")),
        downloadButton("export_pdf", "Export Dashboard as PDF", class = "btn-success")
      ),
      dataTableOutput("Main_table_sup")
    )
  )
)

server <- function(input, output, session) {
  # Reactive value to store data
  val_sup <- reactiveVal(data.frame(
    Date = character(),
    Company = character(),
    Cost = numeric(),
    Quality = numeric(),
    Delivery = numeric(),
    Service = numeric(),
    Technology = numeric(),
    City = character(),
    lon = numeric(),
    lat = numeric(),
    stringsAsFactors = FALSE
  ))
  
  # CSV Upload Handling
  observeEvent(input$upload_csv, {
    req(input$upload_csv)
    tryCatch({
      uploaded_data <- read_csv(input$upload_csv$datapath)
      required_cols <- c("Date", "Company", "Cost", "Quality", "Delivery", 
                        "Service", "Technology", "City", "lon", "lat")
      
      if (all(required_cols %in% names(uploaded_data))) {
        val_sup(uploaded_data)
        shinyalert("Success!", "Data uploaded successfully", type = "success")
      } else {
        shinyalert("Error!", "CSV file must contain all required columns", type = "error")
      }
    }, error = function(e) {
      shinyalert("Error!", "Failed to upload file", type = "error")
    })
  })
  
  # Value box outputs
  output$total_suppliers <- renderText({
    nrow(val_sup())
  })
  
  output$avg_quality <- renderText({
    if(nrow(val_sup()) > 0) mean(val_sup()$Quality) %>% round(1) else "N/A"
  })
  
  output$top_performer <- renderText({
    if(nrow(val_sup()) > 0) {
      val_sup() %>%
        mutate(total_score = Cost + Quality + Service + Technology) %>%
        arrange(desc(total_score)) %>%
        pull(Company) %>%
        first()
    } else "N/A"
  })
  
  # Rankings table
  output$rankings <- renderTable({
    req(nrow(val_sup()) > 0)
    val_sup() %>%
      mutate(
        total_score = Cost + Quality + Service + Technology,
        rank = rank(-total_score, ties.method = "min")
      ) %>%
      select(rank, Company, total_score) %>%
      arrange(rank) %>%
      head(5) %>%
      rename(
        Rank = rank,
        "Total Score" = total_score
      )
  })
  
  # Radar Chart
  output$radarChart <- renderPlotly({
    req(nrow(val_sup()) > 0)
    
    plot <- plot_ly(type = 'scatterpolar', fill = 'toself')
    
    for (i in 1:nrow(val_sup())) {
      plot <- plot %>%
        add_trace(
          r = c(val_sup()$Cost[i], val_sup()$Quality[i], val_sup()$Delivery[i], 
                val_sup()$Service[i], val_sup()$Technology[i], val_sup()$Cost[i]),
          theta = c('Cost', 'Quality', 'Delivery', 'Service', 'Technology', 'Cost'),
          name = val_sup()$Company[i]
        )
    }
    
    plot %>% layout(
      polar = list(
        radialaxis = list(visible = TRUE, range = c(0, 10))
      ),
      showlegend = TRUE
    )
  })
  
  # Scatter Map
  output$scattermap <- renderPlotly({
    req(nrow(val_sup()) > 0)
    
    plot_ly(data = val_sup(),
            type = 'scattermapbox',
            lon = ~lon,
            lat = ~lat,
            text = ~paste("Company:", Company, "<br>City:", City),
            mode = 'markers',
            marker = list(size = 10)
    ) %>%
      layout(
        mapbox = list(
          style = 'open-street-map',
          zoom = 4.1,
          center = list(lon = 12.4964, lat = 41.9028)
        )
      )
  })
  
  # Data table
  output$Main_table_sup <- renderDataTable({
    req(val_sup())
    datatable(val_sup(), options = list(pageLength = 10))
  })
  
  # PDF Export
  output$export_pdf <- downloadHandler(
    filename = function() {
      paste("supplier-report-", Sys.Date(), ".pdf", sep="")
    },
    content = function(file) {
      tempReport <- file.path(tempdir(), "report.Rmd")
      file.copy("report.Rmd", tempReport, overwrite = TRUE)
      
      params <- list(
        data = val_sup(),
        date = Sys.Date()
      )
      
      rmarkdown::render(tempReport,
                       output_file = file,
                       params = params,
                       envir = new.env(parent = globalenv())
      )
    }
  )
}

shinyApp(ui = ui, server = server)
